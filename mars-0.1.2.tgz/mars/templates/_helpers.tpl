{{- define "mars.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "mars.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.nameOverride -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{- define "mars.labels" -}}
helm.sh/chart: {{ printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" }}
{{ include "mars.selectorLabels" . }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end -}}

{{- define "mars.selectorLabels" -}}
app.kubernetes.io/name: {{ include "mars.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}

{{- define "mars.secretName" -}}
{{- default (include "mars.fullname" .) .Values.secrets.existingSecret -}}
{{- end -}}

{{- define "mars.claimName" -}}
{{- default (printf "%s-data" (include "mars.fullname" .)) .Values.persistence.existingClaim -}}
{{- end -}}

{{/* Exec probe for the loopback-only model servers (kubelet can't reach 127.0.0.1 in the Pod) */}}
{{- define "mars.loopbackProbe" -}}
exec:
  command:
    - python
    - -c
    - "import urllib.request; urllib.request.urlopen('http://127.0.0.1:{{ . }}/health', timeout=4)"
timeoutSeconds: 5
{{- end -}}

{{/*
Env + resources for a model container, adding the GPU when gpu.enabled and its count > 0.
Call with (dict "root" $ "name" "embedding" "deviceKey" "EMBEDDING_DEVICE").
env overrides the ConfigMap's *_DEVICE value (env wins over envFrom).
*/}}
{{- define "mars.modelEnvResources" -}}
{{- $gpu := .root.Values.gpu -}}
{{- $count := int (index $gpu .name) -}}
{{- $res := deepCopy (index .root.Values.resources .name) -}}
{{- if and $gpu.enabled (gt $count 0) }}
env:
  - name: {{ .deviceKey }}
    value: cuda
{{- $limits := default dict $res.limits -}}
{{- $_ := set $limits $gpu.resourceName $count -}}
{{- $_ := set $res "limits" $limits -}}
{{- end }}
resources:
  {{- toYaml $res | nindent 2 }}
{{- end -}}

{{/* Fail early if the API would be exposed without the shared token */}}
{{- define "mars.validate" -}}
{{- $exposed := or .Values.ingress.enabled (ne .Values.service.type "ClusterIP") -}}
{{- if and $exposed (not .Values.secrets.existingSecret) (not .Values.secrets.INTERNAL_API_TOKEN) -}}
{{- fail "secrets.INTERNAL_API_TOKEN (or secrets.existingSecret) is required when the API is exposed via ingress or a non-ClusterIP service" -}}
{{- end -}}
{{- end -}}
